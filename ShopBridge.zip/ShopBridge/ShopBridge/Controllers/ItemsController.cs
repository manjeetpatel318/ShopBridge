﻿using System;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using ShopBridge.Data;
using ShopBridge.Model;

namespace ShopBridge.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ItemsController : ControllerBase
    {
        private readonly DataContext db;

        public ItemsController(DataContext db)
        {
            this.db = db;
        }

        //api/Items/GetAllItems
        [HttpGet("GetAllItems")]
        public async Task<IActionResult> GetItems()
        {
            try
            {
                var items = await db.Items.ToListAsync();
                return StatusCode(200, items);
            }
            catch(Exception ex)
            {
                return StatusCode(500, ex.Message);
            }
            
        }

        //api/Items/AddItem
        [HttpPost("AddItem")]
        public async Task<bool> AddItem(ItemModel item)
        {
            try
            {
                await db.Items.AddAsync(item);
                if (await db.SaveChangesAsync() > 0)
                    return true;
                else
                    return false;
            }
            catch
            {
                return false;
            }
        }

        //api/Items/DeleteItem/2
        [HttpDelete("DeleteItem/{id}")]
        public async Task<IActionResult> DeleteItem(int id)
        {
            try
            {
                var item = await db.Items.FindAsync(id);
                if(item != null)
                {
                    db.Items.Remove(item);
                    await db.SaveChangesAsync();
                    return StatusCode(200,"Item Id: "+id+ " removed");
                }
                else
                {
                    return StatusCode(404,"Item not found");
                }
                
            }
            catch(Exception ex)
            {
                return StatusCode(500, ex.Message);
            }
        }

        //api/Items/UpdateItem
        [HttpPut("UpdateItem")]
        public async Task<IActionResult> UpdateItem(ItemModel item)
        {
            try
            {
                var itemToUpdate = await db.Items.Where(a => a.ItemId == item.ItemId).FirstOrDefaultAsync<ItemModel>();

                if(itemToUpdate != null)
                {
                    itemToUpdate.Name = item.Name;
                    itemToUpdate.Description = item.Description;
                    itemToUpdate.Availability = item.Availability;
                    itemToUpdate.Price = item.Price;

                    db.Items.Update(itemToUpdate);
                    await db.SaveChangesAsync();
                    return StatusCode(200,"Item updated");
                    
                }
                else
                {
                    return StatusCode(404, "Item not found");
                }
            }
            catch(Exception ex)
            {
                return StatusCode(500, ex.Message);
            }
        }
    }
}
