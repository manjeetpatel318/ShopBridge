﻿using Microsoft.EntityFrameworkCore;
using System.ComponentModel.DataAnnotations;

namespace ShopBridge.Model
{
    public class ItemModel
    {
        [Key]
        public int ItemId { get; set; }
        [Required (ErrorMessage = "Please mention name of the item")]
        [StringLength(50)]
        public string Name { get; set; }
        [StringLength(256)]
        public string Description { get; set; }
        [Required(ErrorMessage = "Please mention price of the item")]
        public int Price { get; set; }
        [Required(ErrorMessage = "Please mention availability of the item")]
        public bool Availability { get; set; }
    }
}
